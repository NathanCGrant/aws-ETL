from .data_mapping_utils import determine_table_name

__all__ = [
    "determine_table_name"
]

VERSION = "1.0.0"
